@extends('layouts.app', [
    'title' => __('docs.buku_panduan_dokumentasi_penggunaan'),
    'headerTitle' => 'Pusat Dokumentasi & Panduan Cooca',
    'headerSubtitle' => 'Panduan terpadu pengoperasian seluruh modul ERP, Kasir POS, dan administrasi bisnis Cooca'
])

@section('content')
<div class="max-w-[1400px] mx-auto space-y-6 pb-28 lg:pb-16"
    x-data="{
        searchQuery: '',
        activeTab: 'all',
        expandedFaq: null,
        copiedShortcut: null,
        printGuide() {
            window.print();
        },
        copyText(text) {
            if (navigator.clipboard) {
                navigator.clipboard.writeText(text);
                this.copiedShortcut = text;
                setTimeout(() => { this.copiedShortcut = null; }, 2000);
            }
        },
        matchesSearch(text) {
            if (!this.searchQuery.trim()) return true;
            return text.toLowerCase().includes(this.searchQuery.toLowerCase().trim());
        }
    }">

    <!-- ===================================================== -->
    <!-- 1. TOOLBAR / PAGE HEADER & QUICK SEARCH HERO         -->
    <!-- ===================================================== -->
    <header class="relative overflow-hidden rounded-[20px] backdrop-blur-xl bg-gradient-to-br from-white/90 via-white/80 to-white/60 dark:from-[#1C1C1E]/90 dark:via-[#1C1C1E]/80 dark:to-[#1C1C1E]/60 border border-black/5 dark:border-white/10 p-5 sm:p-7 shadow-[0_4px_20px_rgba(0,0,0,0.03)]">
        <!-- Subtle Glow Aesthetic -->
        <div class="absolute -right-20 -top-20 w-72 h-72 bg-[#007AFF]/10 dark:bg-[#0A84FF]/10 rounded-full blur-3xl pointer-events-none"></div>
        <div class="absolute -left-20 -bottom-20 w-72 h-72 bg-[#34C759]/10 dark:bg-[#30D158]/10 rounded-full blur-3xl pointer-events-none"></div>

        <div class="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
            <div class="space-y-1.5 max-w-2xl">
                <!-- Minimal Breadcrumb -->
                <nav class="flex items-center gap-1.5 text-[11px] font-medium text-black/50 dark:text-white/50">
                    <a href="{{ route('dashboard') }}" class="hover:text-[#007AFF] transition-colors">Dashboard</a>
                    <i data-lucide="chevron-right" class="w-3 h-3 opacity-40"></i>
                    <span class="text-black/80 dark:text-white/80 font-semibold">Pusat Bantuan &amp; Pengetahuan</span>
                    <i data-lucide="chevron-right" class="w-3 h-3 opacity-40"></i>
                    <span class="text-[#007AFF] dark:text-[#0A84FF] font-semibold">Dokumentasi Penggunaan</span>
                </nav>

                <h1 class="text-2xl sm:text-3xl font-extrabold text-black dark:text-white tracking-tight flex items-center gap-2.5">
                    <span class="w-9 h-9 rounded-xl bg-gradient-to-br from-[#007AFF] to-[#5856D6] text-white flex items-center justify-center shadow-[0_2px_8px_rgba(0,122,255,0.3)]">
                        <i data-lucide="book-open" class="w-5 h-5"></i>
                    </span>
                    <span>{{ __('docs.buku_panduan_dokumentasi_cooca') }}</span>
                </h1>
                <p class="text-[13px] sm:text-[14px] text-black/60 dark:text-white/60 leading-relaxed">
                    Panduan praktis pengoperasian seluruh ekosistem Cooca: dari transaksi kasir POS, kalkulasi HPP resep otomatis, manajemen inventori multi-gudang, hingga pembukuan akuntansi dan penggajian.
                </p>
            </div>

            <!-- Action Buttons: Print PDF & Lapor Kendala -->
            <div class="flex items-center gap-2.5 flex-wrap shrink-0">
                <button type="button" @click="printGuide()"
                    class="h-9 px-3.5 rounded-xl bg-black/[0.04] dark:bg-white/[0.06] hover:bg-black/[0.08] dark:hover:bg-white/[0.1] text-black/75 dark:text-white/75 text-[12px] font-semibold flex items-center gap-1.5 transition active:scale-95 cursor-pointer">
                    <i data-lucide="printer" class="w-3.5 h-3.5"></i>
                    <span>{{ __('docs.cetak_simpan_pdf') }}</span>
                </button>
                @if(\App\Support\Context::isOwner())
                    <a href="{{ route('feedback.bugs.create') }}"
                        class="h-9 px-4 rounded-xl bg-[#007AFF] hover:bg-[#0062CC] text-white text-[12px] font-semibold flex items-center gap-1.5 shadow-[0_2px_8px_rgba(0,122,255,0.3)] transition active:scale-95">
                        <i data-lucide="message-square-plus" class="w-3.5 h-3.5"></i>
                        <span>{{ __('docs.butuh_bantuan_teknis') }}</span>
                    </a>
                @endif
            </div>
        </div>

        <!-- Live Instant Search Bar -->
        <div class="relative mt-6">
            <div class="relative flex items-center">
                <i data-lucide="search" class="w-4 h-4 text-black/40 dark:text-white/40 absolute left-4 pointer-events-none"></i>
                <input type="text" x-model="searchQuery"
                    placeholder="{{ __('docs.cari_topik_panduan_contoh_tutup_shift') }}"
                    class="w-full h-11 pl-11 pr-24 rounded-xl bg-black/[0.03] dark:bg-white/[0.06] border border-black/10 dark:border-white/10 text-[13px] sm:text-[14px] text-black dark:text-white placeholder:text-black/40 dark:placeholder:text-white/40 focus:outline-none focus:border-[#007AFF] focus:bg-white dark:focus:bg-[#1C1C1E] transition">
                <button type="button" x-show="searchQuery" @click="searchQuery = ''"
                    class="absolute right-3 p-1 rounded-md text-black/40 hover:text-black dark:text-white/40 dark:hover:text-white text-xs font-semibold">
                    Reset
                </button>
            </div>
        </div>
    </header>

    <!-- ===================================================== -->
    <!-- 2. MAIN CONTENT LAYOUT (TWO COLUMNS)                 -->
    <!-- ===================================================== -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

        <!-- 3A. LEFT SIDEBAR: QUICK TOC NAVIGATOR (DESKTOP STICKY - MATCH SIDEBAR STYLE) -->
        <aside class="hidden lg:block lg:col-span-3 sticky top-24 space-y-3">
            <div class="rounded-2xl bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/10 p-3.5 space-y-3 shadow-2xs max-h-[calc(100vh-120px)] overflow-y-auto scrollbar-none">
                <div class="flex items-center justify-between pb-2 border-b border-black/5 dark:border-white/10 px-1">
                    <div class="flex items-center gap-2">
                        <i data-lucide="book-marked" class="w-4 h-4 text-[#007AFF]"></i>
                        <span class="text-[11px] font-bold tracking-wider uppercase text-black/60 dark:text-white/60">Daftar Isi Panduan</span>
                    </div>
                    <span class="text-[10px] font-bold px-2 py-0.5 rounded-md bg-[#007AFF]/10 text-[#007AFF]">5 Klaster</span>
                </div>

                <nav class="space-y-3 text-[12.5px]">

                    <!-- KLASTER 1: CORE BUSINESS -->
                    <div class="space-y-1">
                        <div class="px-2 pt-1 pb-0.5 text-[10px] font-extrabold tracking-wider uppercase text-black/40 dark:text-white/40 select-none">
                            Core Business
                        </div>

                        <!-- Onboarding & Setup Awal -->
                        <a href="#sec-onboarding" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-semibold text-black/80 dark:text-white/80 hover:bg-black/[0.04] dark:hover:bg-white/[0.06] hover:text-[#007AFF] transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-amber-500/15 text-amber-500 dark:bg-amber-400/20 dark:text-amber-400 flex items-center justify-center shrink-0">
                                <i data-lucide="rocket" class="w-3.5 h-3.5"></i>
                            </span>
                            <span class="truncate tracking-tight font-medium text-[12px]">Onboarding &amp; Setup Awal</span>
                        </a>

                        <!-- Kasir POS & Pembayaran -->
                        <a href="#sec-pos" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-semibold text-black/80 dark:text-white/80 hover:bg-black/[0.04] dark:hover:bg-white/[0.06] hover:text-[#007AFF] transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-[#007AFF]/12 text-[#007AFF] dark:bg-[#0A84FF]/20 dark:text-[#0A84FF] flex items-center justify-center shrink-0">
                                <i data-lucide="calculator" class="w-3.5 h-3.5"></i>
                            </span>
                            <span class="truncate tracking-tight font-medium text-[12px]">{{ __('docs.kasir_pos_pembayaran') }}</span>
                        </a>

                        <!-- Penjualan B2B & Invoice -->
                        <a href="#sec-sales-b2b" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-semibold text-black/80 dark:text-white/80 hover:bg-black/[0.04] dark:hover:bg-white/[0.06] hover:text-[#007AFF] transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-blue-500/15 text-blue-600 dark:bg-blue-400/20 dark:text-blue-400 flex items-center justify-center shrink-0">
                                <i data-lucide="receipt" class="w-3.5 h-3.5"></i>
                            </span>
                            <span class="truncate tracking-tight font-medium text-[12px]">Penjualan B2B &amp; Invoice</span>
                        </a>

                        <!-- Modul Analitik & Tren Pertumbuhan -->
                        <a href="#sec-analytics" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-bold text-black dark:text-white hover:bg-blue-500/10 dark:hover:bg-blue-500/15 hover:text-blue-600 transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-blue-500/15 text-blue-600 dark:bg-blue-400/20 dark:text-blue-400 flex items-center justify-center shrink-0">
                                <i data-lucide="bar-chart-3" class="w-3.5 h-3.5"></i>
                            </span>
                            <div class="flex items-center justify-between flex-1 min-w-0">
                                <span class="truncate tracking-tight text-[12px]">Analitik &amp; Tren Bisnis</span>
                                <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">20 Sektor</span>
                            </div>
                        </a>

                        <!-- 3D Virtual Office & Asisten AI -->
                        <div class="space-y-0.5">
                            <a href="#sec-ai" @click="if(activeTab !== 'all') activeTab = 'all'"
                                class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-bold text-black dark:text-white hover:bg-[#AF52DE]/10 dark:hover:bg-[#AF52DE]/15 hover:text-[#AF52DE] transition-all group">
                                <span class="w-6 h-6 rounded-[7px] bg-[#AF52DE]/15 text-[#AF52DE] dark:bg-[#BF5AF2]/20 dark:text-[#BF5AF2] flex items-center justify-center shrink-0">
                                    <i data-lucide="box" class="w-3.5 h-3.5"></i>
                                </span>
                                <div class="flex items-center justify-between flex-1 min-w-0">
                                    <span class="truncate tracking-tight text-[12px]">{{ __('docs.virtual_office_ai') }}</span>
                                    <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 border border-cyan-500/20">{{ __('docs.twenty_businesses') }}</span>
                                </div>
                            </a>

                            <!-- AI Subtree Items (Sidebar Style) -->
                            <div class="ml-5 pl-3 py-1 space-y-1 border-l border-black/10 dark:border-white/10 text-[11px]">
                                <a href="#sec-ai" @click="if(activeTab !== 'all') activeTab = 'all'"
                                    class="flex items-center gap-2 px-2 py-0.5 rounded-[6px] text-black/65 dark:text-white/65 hover:text-[#AF52DE] hover:bg-black/[0.03] dark:hover:bg-white/[0.04] transition">
                                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0"></span>
                                    <span class="truncate">{{ __('docs.tanya_ai_pos_kasir') }}</span>
                                </a>
                                <a href="#sec-ai" @click="if(activeTab !== 'all') activeTab = 'all'"
                                    class="flex items-center gap-2 px-2 py-0.5 rounded-[6px] text-black/65 dark:text-white/65 hover:text-[#AF52DE] hover:bg-black/[0.03] dark:hover:bg-white/[0.04] transition">
                                    <span class="w-1.5 h-1.5 rounded-full bg-cyan-500 shrink-0"></span>
                                    <span class="truncate">Lobi 3 Kantor Spesialis</span>
                                </a>
                                <a href="#sec-ai" @click="if(activeTab !== 'all') activeTab = 'all'"
                                    class="flex items-center gap-2 px-2 py-0.5 rounded-[6px] text-black/65 dark:text-white/65 hover:text-[#AF52DE] hover:bg-black/[0.03] dark:hover:bg-white/[0.04] transition">
                                    <span class="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0"></span>
                                    <span class="truncate">Action Center &amp; Proposal</span>
                                </a>
                                <a href="#sec-ai" @click="if(activeTab !== 'all') activeTab = 'all'"
                                    class="flex items-center gap-2 px-2 py-0.5 rounded-[6px] text-black/65 dark:text-white/65 hover:text-[#AF52DE] hover:bg-black/[0.03] dark:hover:bg-white/[0.04] transition">
                                    <span class="w-1.5 h-1.5 rounded-full bg-purple-500 shrink-0"></span>
                                    <span class="truncate font-semibold text-[#AF52DE] dark:text-[#BF5AF2]">{{ __('docs.matriks_20_industri_umkm') }}</span>
                                </a>
                            </div>
                        </div>

                        <!-- AI Studio Visual & Inspirasi Viral -->
                        <a href="#sec-ai-studio" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-bold text-black dark:text-white hover:bg-rose-500/10 dark:hover:bg-rose-500/15 hover:text-rose-500 transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-[#FF2D55]/15 text-[#FF2D55] dark:bg-[#FF375F]/20 dark:text-[#FF375F] flex items-center justify-center shrink-0">
                                <i data-lucide="sparkles" class="w-3.5 h-3.5"></i>
                            </span>
                            <div class="flex items-center justify-between flex-1 min-w-0">
                                <span class="truncate tracking-tight text-[12px]">AI Studio &amp; Inspirasi</span>
                                <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20">20 Sektor</span>
                            </div>
                        </a>

                        <!-- Komunitas & Event UMKM -->
                        <a href="#sec-community" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-semibold text-black/80 dark:text-white/80 hover:bg-black/[0.04] dark:hover:bg-white/[0.06] hover:text-[#007AFF] transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-teal-500/15 text-teal-600 dark:bg-teal-400/20 dark:text-teal-400 flex items-center justify-center shrink-0">
                                <i data-lucide="messages-square" class="w-3.5 h-3.5"></i>
                            </span>
                            <div class="flex items-center justify-between flex-1 min-w-0">
                                <span class="truncate tracking-tight font-medium text-[12px]">{{ __('docs.komunitas_event_umkm') }}</span>
                                <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-teal-500/10 text-teal-600 dark:text-teal-400 border border-teal-500/20">Tiket QRIS</span>
                            </div>
                        </a>
                    </div>

                    <!-- KLASTER 2: INVENTORY & PROCUREMENT -->
                    <div class="space-y-1 pt-1 border-t border-black/5 dark:border-white/5">
                        <div class="px-2 pt-1.5 pb-0.5 text-[10px] font-extrabold tracking-wider uppercase text-black/40 dark:text-white/40 select-none">
                            Inventory &amp; Supply Chain
                        </div>

                        <!-- Inventori & Resep HPP -->
                        <a href="#sec-inventory" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-semibold text-black/80 dark:text-white/80 hover:bg-black/[0.04] dark:hover:bg-white/[0.06] hover:text-[#007AFF] transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-[#FF9500]/15 text-[#FF9500] dark:bg-[#FF9F0A]/20 dark:text-[#FF9F0A] flex items-center justify-center shrink-0">
                                <i data-lucide="boxes" class="w-3.5 h-3.5"></i>
                            </span>
                            <div class="flex items-center justify-between flex-1 min-w-0">
                                <span class="truncate tracking-tight font-medium text-[12px]">{{ __('docs.stok_resep_multi_gudang') }}</span>
                                <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">Blind Count</span>
                            </div>
                        </a>

                        <!-- Tarif Upah & Biaya Mesin HPP -->
                        <a href="#sec-labor-machines" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-semibold text-black/80 dark:text-white/80 hover:bg-black/[0.04] dark:hover:bg-white/[0.06] hover:text-[#007AFF] transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-amber-500/15 text-amber-600 dark:bg-amber-400/20 dark:text-amber-400 flex items-center justify-center shrink-0">
                                <i data-lucide="cog" class="w-3.5 h-3.5"></i>
                            </span>
                            <div class="flex items-center justify-between flex-1 min-w-0">
                                <span class="truncate tracking-tight font-medium text-[12px]">Tarif Upah &amp; Mesin HPP</span>
                                <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">Manufaktur</span>
                            </div>
                        </a>

                        <!-- Impor Massal Excel & Migrasi -->
                        <a href="#sec-import" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-semibold text-black/80 dark:text-white/80 hover:bg-black/[0.04] dark:hover:bg-white/[0.06] hover:text-[#007AFF] transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-emerald-500/15 text-emerald-600 dark:bg-emerald-400/20 dark:text-emerald-400 flex items-center justify-center shrink-0">
                                <i data-lucide="file-spreadsheet" class="w-3.5 h-3.5"></i>
                            </span>
                            <div class="flex items-center justify-between flex-1 min-w-0">
                                <span class="truncate tracking-tight font-medium text-[12px]">Import Excel &amp; Migrasi</span>
                                <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">4 Domain</span>
                            </div>
                        </a>

                        <!-- Pembelian & Supplier (PO) -->
                        <a href="#sec-procurement" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-semibold text-black/80 dark:text-white/80 hover:bg-black/[0.04] dark:hover:bg-white/[0.06] hover:text-[#007AFF] transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-[#30B0C7]/15 text-[#30B0C7] dark:bg-[#40C8E0]/20 dark:text-[#40C8E0] flex items-center justify-center shrink-0">
                                <i data-lucide="truck" class="w-3.5 h-3.5"></i>
                            </span>
                            <span class="truncate tracking-tight font-medium text-[12px]">Pengadaan &amp; Supplier (PO)</span>
                        </a>
                    </div>

                    <!-- KLASTER 3: FINANCE & ACCOUNTING -->
                    <div class="space-y-1 pt-1 border-t border-black/5 dark:border-white/5">
                        <div class="px-2 pt-1.5 pb-0.5 text-[10px] font-extrabold tracking-wider uppercase text-black/40 dark:text-white/40 select-none">
                            Finance &amp; Accounting
                        </div>

                        <!-- Faktur Penjualan & Invoices -->
                        <a href="#sec-invoices" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-semibold text-black/80 dark:text-white/80 hover:bg-black/[0.04] dark:hover:bg-white/[0.06] hover:text-[#007AFF] transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-[#007AFF]/15 text-[#007AFF] dark:bg-[#0A84FF]/20 dark:text-[#0A84FF] flex items-center justify-center shrink-0">
                                <i data-lucide="file-text" class="w-3.5 h-3.5"></i>
                            </span>
                            <div class="flex items-center justify-between flex-1 min-w-0">
                                <span class="truncate tracking-tight font-medium text-[12px]">Faktur Penjualan (Invoices)</span>
                                <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">Piutang B2B</span>
                            </div>
                        </a>

                        <!-- Keuangan & Akuntansi -->
                        <a href="#sec-finance" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-semibold text-black/80 dark:text-white/80 hover:bg-black/[0.04] dark:hover:bg-white/[0.06] hover:text-[#007AFF] transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-[#34C759]/15 text-[#34C759] dark:bg-[#30D158]/20 dark:text-[#30D158] flex items-center justify-center shrink-0">
                                <i data-lucide="landmark" class="w-3.5 h-3.5"></i>
                            </span>
                            <div class="flex items-center justify-between flex-1 min-w-0">
                                <span class="truncate tracking-tight font-medium text-[12px]">Kas, Bank &amp; Akuntansi</span>
                                <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">15 Hub</span>
                            </div>
                        </a>

                        <!-- Otorisasi Dokumen MAR & Anti-Fraud -->
                        <a href="#sec-approvals" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-bold text-black dark:text-white hover:bg-emerald-500/10 dark:hover:bg-emerald-500/15 hover:text-emerald-600 transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-emerald-600/15 text-emerald-600 dark:bg-emerald-400/20 dark:text-emerald-400 flex items-center justify-center shrink-0">
                                <i data-lucide="check-check" class="w-3.5 h-3.5"></i>
                            </span>
                            <div class="flex items-center justify-between flex-1 min-w-0">
                                <span class="truncate tracking-tight text-[12px]">Otorisasi Dokumen MAR</span>
                                <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">Maker-Checker</span>
                            </div>
                        </a>
                    </div>

                    <!-- KLASTER 4: HRM & CHANNELS -->
                    <div class="space-y-1 pt-1 border-t border-black/5 dark:border-white/5">
                        <div class="px-2 pt-1.5 pb-0.5 text-[10px] font-extrabold tracking-wider uppercase text-black/40 dark:text-white/40 select-none">
                            Human Resources &amp; CRM
                        </div>

                        <!-- Karyawan & Penggajian -->
                        <a href="#sec-hrm" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-semibold text-black/80 dark:text-white/80 hover:bg-black/[0.04] dark:hover:bg-white/[0.06] hover:text-[#007AFF] transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-sky-500/15 text-sky-500 dark:bg-sky-400/20 dark:text-sky-400 flex items-center justify-center shrink-0">
                                <i data-lucide="users" class="w-3.5 h-3.5"></i>
                            </span>
                            <div class="flex items-center justify-between flex-1 min-w-0">
                                <span class="truncate tracking-tight font-medium text-[12px]">{{ __('docs.karyawan_penggajian') }}</span>
                                <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-sky-500/10 text-sky-600 dark:text-sky-400 border border-sky-500/20">Geofence</span>
                            </div>
                        </a>

                        <!-- Master Data Pelanggan & Piutang -->
                        <a href="#sec-customers" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-semibold text-black/80 dark:text-white/80 hover:bg-black/[0.04] dark:hover:bg-white/[0.06] hover:text-[#007AFF] transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-blue-500/15 text-blue-600 dark:bg-blue-400/20 dark:text-blue-400 flex items-center justify-center shrink-0">
                                <i data-lucide="users-round" class="w-3.5 h-3.5"></i>
                            </span>
                            <div class="flex items-center justify-between flex-1 min-w-0">
                                <span class="truncate tracking-tight font-medium text-[12px]">Master Data Pelanggan</span>
                                <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">Piutang &amp; B2B</span>
                            </div>
                        </a>

                        <!-- Loyalitas & CRM Member -->
                        <a href="#sec-crm" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-semibold text-black/80 dark:text-white/80 hover:bg-black/[0.04] dark:hover:bg-white/[0.06] hover:text-[#007AFF] transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-pink-500/15 text-pink-500 dark:bg-pink-400/20 dark:text-pink-400 flex items-center justify-center shrink-0">
                                <i data-lucide="award" class="w-3.5 h-3.5"></i>
                            </span>
                            <div class="flex items-center justify-between flex-1 min-w-0">
                                <span class="truncate tracking-tight font-medium text-[12px]">Loyalitas &amp; CRM Member</span>
                                <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-pink-500/10 text-pink-600 dark:text-pink-400 border border-pink-500/20">Poin &amp; Kupon</span>
                            </div>
                        </a>

                        <!-- Toko Online & 42 Tema Storefront -->
                        <a href="#sec-storefront" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-semibold text-black/80 dark:text-white/80 hover:bg-black/[0.04] dark:hover:bg-white/[0.06] hover:text-[#007AFF] transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-indigo-500/15 text-indigo-500 dark:bg-indigo-400/20 dark:text-indigo-400 flex items-center justify-center shrink-0">
                                <i data-lucide="globe" class="w-3.5 h-3.5"></i>
                            </span>
                            <div class="flex items-center justify-between flex-1 min-w-0">
                                <span class="truncate tracking-tight font-medium text-[12px]">Toko Online &amp; 42 Tema</span>
                                <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">6 Arketipe</span>
                            </div>
                        </a>
                    </div>

                    <!-- KLASTER 5: SYSTEM & SETTINGS -->
                    <div class="space-y-1 pt-1 border-t border-black/5 dark:border-white/5">
                        <div class="px-2 pt-1.5 pb-0.5 text-[10px] font-extrabold tracking-wider uppercase text-black/40 dark:text-white/40 select-none">
                            System &amp; Panduan
                        </div>

                        <!-- Paket Langganan, Kuota & Billing -->
                        <a href="#sec-billing" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-bold text-black dark:text-white hover:bg-purple-500/10 dark:hover:bg-purple-500/15 hover:text-purple-600 transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-purple-500/15 text-purple-600 dark:bg-purple-400/20 dark:text-purple-400 flex items-center justify-center shrink-0">
                                <i data-lucide="credit-card" class="w-3.5 h-3.5"></i>
                            </span>
                            <div class="flex items-center justify-between flex-1 min-w-0">
                                <span class="truncate tracking-tight text-[12px]">Langganan &amp; Billing</span>
                                <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20">TriPay QRIS</span>
                            </div>
                        </a>

                        <!-- Pusat Feedback & Laporan Masalah -->
                        <a href="#sec-feedback" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-semibold text-black/80 dark:text-white/80 hover:bg-black/[0.04] dark:hover:bg-white/[0.06] hover:text-[#007AFF] transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-rose-500/15 text-rose-600 dark:bg-rose-400/20 dark:text-rose-400 flex items-center justify-center shrink-0">
                                <i data-lucide="message-square" class="w-3.5 h-3.5"></i>
                            </span>
                            <div class="flex items-center justify-between flex-1 min-w-0">
                                <span class="truncate tracking-tight font-medium text-[12px]">Pusat Feedback &amp; Bug</span>
                                <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20">Bugs &amp; Request</span>
                            </div>
                        </a>

                        <!-- Pintasan Keyboard -->
                        <a href="#sec-shortcuts" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-semibold text-black/80 dark:text-white/80 hover:bg-black/[0.04] dark:hover:bg-white/[0.06] hover:text-[#007AFF] transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-[#5856D6]/15 text-[#5856D6] dark:bg-[#5E5CE6]/20 dark:text-[#5E5CE6] flex items-center justify-center shrink-0">
                                <i data-lucide="command" class="w-3.5 h-3.5"></i>
                            </span>
                            <span class="truncate tracking-tight font-medium text-[12px]">Pintasan Keyboard</span>
                        </a>

                        <!-- Tanya Jawab (FAQ) -->
                        <a href="#sec-faq" @click="if(activeTab !== 'all') activeTab = 'all'"
                            class="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-[10px] font-semibold text-black/80 dark:text-white/80 hover:bg-black/[0.04] dark:hover:bg-white/[0.06] hover:text-[#007AFF] transition-all group">
                            <span class="w-6 h-6 rounded-[7px] bg-rose-500/15 text-rose-500 dark:bg-rose-400/20 dark:text-rose-400 flex items-center justify-center shrink-0">
                                <i data-lucide="help-circle" class="w-3.5 h-3.5"></i>
                            </span>
                            <span class="truncate tracking-tight font-medium text-[12px]">Tanya Jawab (FAQ)</span>
                        </a>
                    </div>

                </nav>
            </div>

            <!-- Quick Info Card -->
            <div class="rounded-2xl p-4 bg-gradient-to-br from-[#007AFF]/10 to-[#5856D6]/10 border border-[#007AFF]/20 text-xs space-y-2">
                <div class="flex items-center gap-2 font-bold text-black dark:text-white">
                    <i data-lucide="sparkles" class="w-4 h-4 text-[#007AFF]"></i>
                    <span>Pencarian Cepat Spotlight</span>
                </div>
                <p class="text-[11px] text-black/60 dark:text-white/60 leading-relaxed">
                    Tekan tombol <kbd class="px-1.5 py-0.5 rounded bg-black/10 dark:bg-white/10 font-mono text-[10px] font-bold">Ctrl + K</kbd> atau <kbd class="px-1.5 py-0.5 rounded bg-black/10 dark:bg-white/10 font-mono text-[10px] font-bold">Cmd + K</kbd> kapan saja untuk membuka menu instan.
                </p>
            </div>
        </aside>

        <!-- 3B. RIGHT MAIN COLUMN: COMPREHENSIVE DOCUMENTATION CONTENT -->
        <main class="lg:col-span-9 space-y-8">

            <!-- ===================================================== -->
            <!-- SECTION 1: ONBOARDING & SETUP AWAL (GETTING STARTED)  -->
            <!-- ===================================================== -->
            <section id="sec-onboarding" class="space-y-4"
                x-show="(activeTab === 'all' || activeTab === 'getting_started') && matchesSearch('onboarding setup toko profil cabang pajak pengguna karyawan')">

                <div class="flex items-center justify-between gap-3 pb-2 border-b border-black/5 dark:border-white/10">
                    <div class="flex items-center gap-2.5">
                        <span class="w-8 h-8 rounded-xl bg-amber-500/15 text-amber-500 flex items-center justify-center font-bold text-sm">
                            1
                        </span>
                        <div>
                            <h2 class="text-lg sm:text-xl font-bold text-black dark:text-white tracking-tight">{{ __('docs.onboarding_setup_awal_usaha') }}</h2>
                            <p class="text-xs text-black/50 dark:text-white/50">Langkah wajib 5 menit sebelum memulai penjualan</p>
                        </div>
                    </div>
                    <a href="{{ route('settings.index') }}" class="text-[11px] font-semibold text-[#007AFF] hover:underline flex items-center gap-1">
                        <span>{{ __('docs.buka_pengaturan') }}</span>
                        <i data-lucide="arrow-right" class="w-3 h-3"></i>
                    </a>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <!-- Step 1.1 -->
                    <div class="p-4 sm:p-5 rounded-2xl bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/10 space-y-2 shadow-2xs">
                        <div class="flex items-center gap-2 text-xs font-bold text-black dark:text-white">
                            <span class="w-5 h-5 rounded-full bg-black/5 dark:bg-white/10 flex items-center justify-center text-[11px]">1.1</span>
                            <span>Profil Usaha &amp; Identitas Struk</span>
                        </div>
                        <p class="text-xs text-black/60 dark:text-white/60 leading-relaxed">
                            Buka menu <strong>Pengaturan &rarr; Profil Bisnis</strong>. Isi nama toko, logo, alamat lengkap, dan nomor kontak WhatsApp. Informasi ini akan otomatis tercetak pada struk kasir dan dokumen faktur resmi.
                        </p>
                    </div>

                    <!-- Step 1.2 -->
                    <div class="p-4 sm:p-5 rounded-2xl bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/10 space-y-2 shadow-2xs">
                        <div class="flex items-center gap-2 text-xs font-bold text-black dark:text-white">
                            <span class="w-5 h-5 rounded-full bg-black/5 dark:bg-white/10 flex items-center justify-center text-[11px]">1.2</span>
                            <span>Pajak (PB1/PPN) &amp; Service Charge</span>
                        </div>
                        <p class="text-xs text-black/60 dark:text-white/60 leading-relaxed">
                            Tentukan apakah harga jual sudah termasuk pajak (*Tax Inclusive*) atau ditambahkan di kasir (*Tax Exclusive*). Aktifkan juga biaya layanan (*Service Charge*) khusus untuk resto/cafe bila diperlukan.
                        </p>
                    </div>

                    <!-- Step 1.3 -->
                    <div class="p-4 sm:p-5 rounded-2xl bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/10 space-y-2 shadow-2xs">
                        <div class="flex items-center gap-2 text-xs font-bold text-black dark:text-white">
                            <span class="w-5 h-5 rounded-full bg-black/5 dark:bg-white/10 flex items-center justify-center text-[11px]">1.3</span>
                            <span>Multi-Gudang &amp; Cabang Awal</span>
                        </div>
                        <p class="text-xs text-black/60 dark:text-white/60 leading-relaxed">
                            Buka <strong>Inventori &rarr; Gudang</strong>. Buat minimal satu gudang utama (contoh: *Gudang Pusat* atau *Toko Utama*). Setiap mutasi stok kasir dan pembelian akan terhubung ke gudang ini.
                        </p>
                    </div>

                    <!-- Step 1.4 -->
                    <div class="p-4 sm:p-5 rounded-2xl bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/10 space-y-2 shadow-2xs">
                        <div class="flex items-center gap-2 text-xs font-bold text-black dark:text-white">
                            <span class="w-5 h-5 rounded-full bg-black/5 dark:bg-white/10 flex items-center justify-center text-[11px]">1.4</span>
                            <span>Akun Staf &amp; Hak Akses (RBAC)</span>
                        </div>
                        <p class="text-xs text-black/60 dark:text-white/60 leading-relaxed">
                            Buka <strong>Pengaturan &rarr; Peran &amp; Hak Akses</strong>. Daftarkan akun kasir, admin gudang, atau staf dapur dengan membatasi akses sensitif (misal: kasir tidak bisa melihat laba rugi atau menghapus riwayat audit).
                        </p>
                    </div>
                </div>

                <!-- Pro Tips Callout -->
                <div class="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 flex items-start gap-3 text-xs text-amber-900 dark:text-amber-200">
                    <i data-lucide="lightbulb" class="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5"></i>
                    <div>
                        <strong class="font-bold">Tips Master Data:</strong>
                        <span> Jika Anda memiliki ratusan produk yang sudah tercatat di Excel, gunakan fitur <strong>Import Excel</strong> di sidebar untuk mengunggah seluruh produk dan stok awal sekaligus dalam hitungan detik.</span>
                    </div>
                </div>
            </section>

            <!-- ===================================================== -->
            <!-- SECTION 2: KASIR MODERN (POS) & PRINTER BLUETOOTH    -->
            <!-- ===================================================== -->
            <section id="sec-pos" class="space-y-4"
                x-show="(activeTab === 'all' || activeTab === 'pos') && matchesSearch('kasir pos retail f&b dine in meja split bill qris printer shift kas modal tutup')">

                <div class="flex items-center justify-between gap-3 pb-2 border-b border-black/5 dark:border-white/10">
                    <div class="flex items-center gap-2.5">
                        <span class="w-8 h-8 rounded-xl bg-[#007AFF]/15 text-[#007AFF] flex items-center justify-center font-bold text-sm">
                            2
                        </span>
                        <div>
                            <h2 class="text-lg sm:text-xl font-bold text-black dark:text-white tracking-tight">{{ __('docs.kasir_modern_pos_pembayaran_shift') }}</h2>
                            <p class="text-xs text-black/50 dark:text-white/50">Pengoperasian harian kasir untuk toko retail maupun resto dine-in</p>
                        </div>
                    </div>
                    @if(\App\Support\Context::hasPermission('pos.terminal'))
                        <a href="{{ route('pos.terminal') }}" class="text-[11px] font-semibold text-[#007AFF] hover:underline flex items-center gap-1">
                            <span>{{ __('docs.buka_mesin_kasir') }}</span>
                            <i data-lucide="arrow-right" class="w-3 h-3"></i>
                        </a>
                    @endif
                </div>

                <!-- POS Step-by-Step Flow Card -->
                <div class="p-5 rounded-2xl bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/10 space-y-4 shadow-2xs">
                    <h3 class="text-xs font-bold uppercase tracking-wider text-black/50 dark:text-white/50">{{ __('docs.alur_standar_kasir_sehari_hari') }}</h3>

                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                        <div class="p-3 rounded-xl bg-black/[0.02] dark:bg-white/[0.03] border border-black/5 dark:border-white/5 space-y-1">
                            <span class="font-bold text-[#007AFF]">Langkah 1: Buka Shift</span>
                            <p class="text-black/60 dark:text-white/60 text-[11px]">Kasir memasukkan modal awal uang tunai laci (*Starting Cash*) saat memulai jam kerja.</p>
                        </div>
                        <div class="p-3 rounded-xl bg-black/[0.02] dark:bg-white/[0.03] border border-black/5 dark:border-white/5 space-y-1">
                            <span class="font-bold text-[#007AFF]">Langkah 2: Input Pesanan</span>
                            <p class="text-black/60 dark:text-white/60 text-[11px]">Scan barcode produk atau pilih menu. Untuk resto, tentukan nomor meja dan modifier produk.</p>
                        </div>
                        <div class="p-3 rounded-xl bg-black/[0.02] dark:bg-white/[0.03] border border-black/5 dark:border-white/5 space-y-1">
                            <span class="font-bold text-[#007AFF]">Langkah 3: Pembayaran</span>
                            <p class="text-black/60 dark:text-white/60 text-[11px]">Pilih metode bayar: Tunai (Quick Cash), QRIS Statis/Dinamis, Transfer Bank, atau Split Bill.</p>
                        </div>
                        <div class="p-3 rounded-xl bg-black/[0.02] dark:bg-white/[0.03] border border-black/5 dark:border-white/5 space-y-1">
                            <span class="font-bold text-[#007AFF]">Langkah 4: Tutup Shift (Z)</span>
                            <p class="text-black/60 dark:text-white/60 text-[11px]">Hitung uang kas fisik, sistem mencocokkan selisih kas, lalu cetak laporan Z-Report kasir.</p>
                        </div>
                    </div>

                    <div class="space-y-3 pt-2 text-xs text-black/70 dark:text-white/70">
                        <h4 class="font-bold text-black dark:text-white text-sm">{{ __('docs.fitur_kasir_unggulan_di_cooca') }}</h4>
                        <ul class="space-y-2 list-disc list-inside">
                            <li><strong>Split Bill (Bagi Tagihan):</strong> Pelanggan dalam satu meja dapat membayar terpisah per orang atau membagi total tagihan menjadi beberapa pembayaran.</li>
                            <li><strong>Kitchen Display &amp; Tiket Dapur (KDS):</strong> Setelah pesanan disimpan, tiket makanan/minuman otomatis terkirim ke printer dapur dan layar barista.</li>
                            <li><strong>QRIS Dinamis Otomatis:</strong> Nilai transaksi otomatis tertanam pada barcode QRIS pelanggan tanpa perlu kasir mengetik ulang nominal di EDC.</li>
                            <li><strong>Konfigurasi Printer Bluetooth / USB:</strong> Buka <strong>Pengaturan Kasir &rarr; Printer</strong>. Cooca mendukung printer thermal ukuran 58mm dan 80mm standar industri.</li>
                        </ul>
                    </div>
                </div>

                <!-- Anti-Fraud Warning Box -->
                <div class="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800/50 flex items-start gap-3 text-xs text-rose-900 dark:text-rose-200">
                    <i data-lucide="shield-alert" class="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5"></i>
                    <div>
                        <strong class="font-bold">Keamanan &amp; Deteksi Fraud Kasir:</strong>
                        <span> Setiap tindakan void transaksi, pembatalan pesanan yang sudah tercetak, atau pemberian diskon di atas batas normal akan tercatat di <strong>Audit Anti-Fraud</strong> dan mewajibkan otorisasi PIN Supervisor/Owner.</span>
                    </div>
                </div>
            </section>

            <!-- ===================================================== -->
            <!-- SECTION 3: INVENTORI, MULTI-GUDANG & HPP RESEP (BOM)  -->
            <!-- (PANDUAN LENGKAP 20 JENIS USAHA & BLIND COUNT OPNAME) -->
            <!-- ===================================================== -->
            @include('app.docs.partials.sec_inventory')

            <!-- ===================================================== -->
            <!-- SECTION: TARIF UPAH KERJA & BIAYA MESIN PRODUKSI      -->
            <!-- (PANDUAN LENGKAP 20 JENIS USAHA & AKURASI HPP B2B)    -->
            <!-- ===================================================== -->
            @include('app.docs.partials.sec_labor_machines')

            <!-- ===================================================== -->
            <!-- SECTION: PUSAT IMPORT MASSAL EXCEL & MIGRASI DATA     -->
            <!-- (PANDUAN LENGKAP 20 JENIS USAHA & SMART LIVING LOOKUP)-->
            <!-- ===================================================== -->
            @include('app.docs.partials.sec_import')

            <!-- ===================================================== -->
            <!-- SECTION 4: PENGADAAN & PEMBELIAN (PROCUREMENT)        -->
            <!-- ===================================================== -->
            <section id="sec-procurement" class="space-y-4"
                x-show="(activeTab === 'all' || activeTab === 'sales_purchasing') && matchesSearch('pembelian procurement po purchase order supplier grn penerimaan barang tagihan ap')">

                <div class="flex items-center justify-between gap-3 pb-2 border-b border-black/5 dark:border-white/10">
                    <div class="flex items-center gap-2.5">
                        <span class="w-8 h-8 rounded-xl bg-indigo-500/15 text-indigo-500 flex items-center justify-center font-bold text-sm">
                            4
                        </span>
                        <div>
                            <h2 class="text-lg sm:text-xl font-bold text-black dark:text-white tracking-tight">{{ __('docs.pengadaan_pembelian_po_ke_supplier') }}</h2>
                            <p class="text-xs text-black/50 dark:text-white/50">Alur standar pengadaan barang, penerimaan surat jalan, dan jatuh tempo hutang dagang</p>
                        </div>
                    </div>
                    @if(\App\Support\Context::hasPermission('purchasing.view'))
                        <a href="{{ route('purchase-orders.index') }}" class="text-[11px] font-semibold text-[#007AFF] hover:underline flex items-center gap-1">
                            <span>{{ __('docs.buka_purchase_orders') }}</span>
                            <i data-lucide="arrow-right" class="w-3 h-3"></i>
                        </a>
                    @endif
                </div>

                <div class="p-5 rounded-2xl bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/10 space-y-4 shadow-2xs">
                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                        <div class="p-3 rounded-xl bg-black/[0.02] dark:bg-white/[0.03] border border-black/5 dark:border-white/5 space-y-1">
                            <span class="font-bold text-indigo-500">1. Terbitkan PO</span>
                            <p class="text-black/60 dark:text-white/60 text-[11px]">Pilih supplier, tentukan kuantiti barang dan harga satuan yang disepakati.</p>
                        </div>
                        <div class="p-3 rounded-xl bg-black/[0.02] dark:bg-white/[0.03] border border-black/5 dark:border-white/5 space-y-1">
                            <span class="font-bold text-indigo-500">2. Terima Barang (GRN)</span>
                            <p class="text-black/60 dark:text-white/60 text-[11px]">Saat barang tiba di gudang, admin memverifikasi fisik barang dan stok gudang otomatis bertambah.</p>
                        </div>
                        <div class="p-3 rounded-xl bg-black/[0.02] dark:bg-white/[0.03] border border-black/5 dark:border-white/5 space-y-1">
                            <span class="font-bold text-indigo-500">3. Faktur Beli &amp; Hutang</span>
                            <p class="text-black/60 dark:text-white/60 text-[11px]">Sistem mencatat kewajiban hutang dagang (AP) lengkap dengan jadwal tanggal jatuh tempo.</p>
                        </div>
                    </div>
                </div>
            </section>

            <!-- ===================================================== -->
            <!-- SECTION 5: FAKTUR PENJUALAN & INVOICE COMMERCE        -->
            <!-- (PANDUAN LENGKAP 20 JENIS USAHA & PENAGIHAN PIUTANG)  -->
            <!-- ===================================================== -->
            @include('app.docs.partials.sec_invoices')

            <!-- ===================================================== -->
            <!-- SECTION: MODUL ANALITIK & TREN PERTUMBUHAN BISNIS    -->
            <!-- (PANDUAN LENGKAP 20 JENIS USAHA & ROUTE VERIFIKASI)  -->
            <!-- ===================================================== -->
            @include('app.docs.partials.sec_analytics')

            <!-- ===================================================== -->
            <!-- SECTION 6: PUSAT KEUANGAN, KAS & REKONSILIASI         -->
            <!-- (PANDUAN LENGKAP 20 JENIS USAHA & 15 HUB FINANSIAL)  -->
            <!-- ===================================================== -->
            @include('app.docs.partials.sec_finance')

            <!-- ===================================================== -->
            <!-- SECTION 7: HRM, PRESENSI GEOFENCE & PENGGAJIAN OTOMATIS-->
            <!-- (PANDUAN LENGKAP 20 JENIS USAHA & BIOMETRIK GEOFENCE) -->
            <!-- ===================================================== -->
            @include('app.docs.partials.sec_hrm')

            <!-- ===================================================== -->
            <!-- SECTION: MODUL MASTER PELANGGAN & MANAJEMEN PIUTANG   -->
            <!-- (PANDUAN LENGKAP 20 JENIS USAHA & DELETION GUARD)     -->
            <!-- ===================================================== -->
            @include('app.docs.partials.sec_customers')

            <!-- ===================================================== -->
            <!-- SECTION: MODUL CRM, LOYALITAS MEMBER & VOUCHER PROMO  -->
            <!-- (PANDUAN LENGKAP 20 JENIS USAHA & ANTI-LAPPING WA)    -->
            <!-- ===================================================== -->
            @include('app.docs.partials.sec_crm')

            <!-- ===================================================== -->
            <!-- SECTION: TOKO ONLINE & 42 TEMA STOREFRONT UNIVERSAL    -->
            <!-- (PANDUAN LENGKAP 20 JENIS USAHA & 6 ARKETIPE DESAIN)   -->
            <!-- ===================================================== -->
            @include('app.docs.partials.sec_storefront')

            <!-- ===================================================== -->
            <!-- SECTION: MODUL KOMUNITAS BISNIS, EVENT & TIKET QRIS   -->
            <!-- (PANDUAN LENGKAP 20 JENIS USAHA & PRESENSI GPS/QRIS)  -->
            <!-- ===================================================== -->
            @include('app.docs.partials.sec_community')

            <!-- ===================================================== -->
            <!-- SECTION 10: OTORISASI (MAR) & AUDIT ANTI-FRAUD       -->
            <!-- (PANDUAN LENGKAP 20 JENIS USAHA & ROUTE VERIFIKASI)  -->
            <!-- ===================================================== -->
            @include('app.docs.partials.sec_approvals')

            <!-- ===================================================== -->
            <!-- SECTION 11: PAKET LANGGANAN, KUOTA & BILLING         -->
            <!-- (PANDUAN LENGKAP 20 JENIS USAHA & TRIPAY INSTAN 24/7)-->
            <!-- ===================================================== -->
            @include('app.docs.partials.sec_billing')

            <!-- ===================================================== -->
            <!-- SECTION 12: ASISTEN PINTAR AI & INTELIJEN BISNIS      -->
            <!-- (PANDUAN LENGKAP 20 JENIS USAHA & LINK TUTORIAL)      -->
            <!-- ===================================================== -->
            @include('app.docs.partials.sec_ai')

            <!-- ===================================================== -->
            <!-- SECTION 12B: AI STUDIO VISUAL & MATERI PROMOSI       -->
            <!-- (PANDUAN LENGKAP 20 JENIS USAHA & LINK TUTORIAL)      -->
            <!-- ===================================================== -->
            @include('app.docs.partials.sec_ai_studio')

            <!-- ===================================================== -->
            <!-- SECTION 12C: PUSAT FEEDBACK & LAPORAN MASALAH (BUGS)  -->
            <!-- (PANDUAN LENGKAP 20 JENIS USAHA & JALUR ENGINEERING)  -->
            <!-- ===================================================== -->
            @include('app.docs.partials.sec_feedback')

            <!-- ===================================================== -->
            <!-- SECTION 13: PINTASAN KEYBOARD (SHORTCUTS)            -->
            <!-- ===================================================== -->
            <section id="sec-shortcuts" class="space-y-4"
                x-show="(activeTab === 'all' || activeTab === 'shortcuts') && matchesSearch('shortcut pintasan tombol keyboard f1 f2 f4 bayar cepat cari')">

                <div class="flex items-center justify-between gap-3 pb-2 border-b border-black/5 dark:border-white/10">
                    <div class="flex items-center gap-2.5">
                        <span class="w-8 h-8 rounded-xl bg-amber-500/15 text-amber-500 flex items-center justify-center font-bold text-sm">
                            13
                        </span>
                        <div>
                            <h2 class="text-lg sm:text-xl font-bold text-black dark:text-white tracking-tight">Tabel Pintasan Keyboard (Keyboard Shortcuts)</h2>
                            <p class="text-xs text-black/50 dark:text-white/50">Percepat transaksi kasir dan navigasi sistem tanpa menyentuh mouse</p>
                        </div>
                    </div>
                </div>

                <div class="rounded-2xl bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/10 overflow-hidden shadow-2xs">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-xs">
                            <thead class="bg-black/[0.03] dark:bg-white/[0.04] border-b border-black/5 dark:border-white/10 text-[11px] font-bold text-black/60 dark:text-white/60 uppercase">
                                <tr>
                                    <th class="px-4 py-3">Tombol Pintas</th>
                                    <th class="px-4 py-3">Lokasi / Modul</th>
                                    <th class="px-4 py-3">Fungsi Pintasan</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-black/5 dark:divide-white/5">
                                <tr>
                                    <td class="px-4 py-3 font-mono font-bold text-[#007AFF]">
                                        <kbd class="px-2 py-1 rounded bg-black/5 dark:bg-white/10 border border-black/10 dark:border-white/10">F2</kbd>
                                    </td>
                                    <td class="px-4 py-3 text-black/70 dark:text-white/70">Mesin Kasir (POS)</td>
                                    <td class="px-4 py-3 text-black/90 dark:text-white font-medium">Buka Dialog Pembayaran Cepat (Quick Pay)</td>
                                </tr>
                                <tr>
                                    <td class="px-4 py-3 font-mono font-bold text-[#007AFF]">
                                        <kbd class="px-2 py-1 rounded bg-black/5 dark:bg-white/10 border border-black/10 dark:border-white/10">F4</kbd>
                                    </td>
                                    <td class="px-4 py-3 text-black/70 dark:text-white/70">Mesin Kasir (POS)</td>
                                    <td class="px-4 py-3 text-black/90 dark:text-white font-medium">Fokus ke Kolom Cari Produk / Barcode</td>
                                </tr>
                                <tr>
                                    <td class="px-4 py-3 font-mono font-bold text-[#007AFF]">
                                        <kbd class="px-2 py-1 rounded bg-black/5 dark:bg-white/10 border border-black/10 dark:border-white/10">Ctrl + K</kbd> / <kbd class="px-2 py-1 rounded bg-black/5 dark:bg-white/10 border border-black/10 dark:border-white/10">Cmd + K</kbd>
                                    </td>
                                    <td class="px-4 py-3 text-black/70 dark:text-white/70">Global (Seluruh Layar)</td>
                                    <td class="px-4 py-3 text-black/90 dark:text-white font-medium">Buka Navigasi Cepat Spotlight Palette</td>
                                </tr>
                                <tr>
                                    <td class="px-4 py-3 font-mono font-bold text-[#007AFF]">
                                        <kbd class="px-2 py-1 rounded bg-black/5 dark:bg-white/10 border border-black/10 dark:border-white/10">Esc</kbd>
                                    </td>
                                    <td class="px-4 py-3 text-black/70 dark:text-white/70">Global (Seluruh Layar)</td>
                                    <td class="px-4 py-3 text-black/90 dark:text-white font-medium">Tutup Modal Dialog / Popup Aktif</td>
                                </tr>
                                <tr>
                                    <td class="px-4 py-3 font-mono font-bold text-[#007AFF]">
                                        <kbd class="px-2 py-1 rounded bg-black/5 dark:bg-white/10 border border-black/10 dark:border-white/10">Ctrl + P</kbd>
                                    </td>
                                    <td class="px-4 py-3 text-black/70 dark:text-white/70">Nota Kasir / Laporan</td>
                                    <td class="px-4 py-3 text-black/90 dark:text-white font-medium">Cetak Dokumen atau Cetak Ulang Struk</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>

            <!-- ===================================================== -->
            <!-- SECTION 14: FAQ & PEMECAHAN MASALAH (TROUBLESHOOTING) -->
            <!-- ===================================================== -->
            <section id="sec-faq" class="space-y-4"
                x-show="(activeTab === 'all' || activeTab === 'faq') && matchesSearch('faq tanya jawab kendala error masalah printer selisih lupa sandi bluetooth')">

                <div class="flex items-center justify-between gap-3 pb-2 border-b border-black/5 dark:border-white/10">
                    <div class="flex items-center gap-2.5">
                        <span class="w-8 h-8 rounded-xl bg-rose-500/15 text-rose-500 flex items-center justify-center font-bold text-sm">
                            14
                        </span>
                        <div>
                            <h2 class="text-lg sm:text-xl font-bold text-black dark:text-white tracking-tight">Tanya Jawab Populer (FAQ) &amp; Solusi Kendala</h2>
                            <p class="text-xs text-black/50 dark:text-white/50">Pertanyaan umum dan solusi cepat penanganan masalah operasional</p>
                        </div>
                    </div>
                </div>

                <div class="space-y-3">
                    <!-- FAQ 1 -->
                    <div class="rounded-2xl bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/10 overflow-hidden shadow-2xs">
                        <button type="button" @click="expandedFaq = (expandedFaq === 1 ? null : 1)"
                            class="w-full p-4.5 text-left flex items-center justify-between gap-3 font-bold text-xs sm:text-sm text-black dark:text-white hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition cursor-pointer">
                            <span>Bagaimana jika printer thermal bluetooth tidak mau mencetak struk?</span>
                            <i data-lucide="chevron-down" class="w-4 h-4 transition-transform text-black/40 dark:text-white/40"
                                :class="expandedFaq === 1 ? 'rotate-180' : ''"></i>
                        </button>
                        <div x-show="expandedFaq === 1" x-collapse class="px-4.5 pb-4.5 text-xs text-black/60 dark:text-white/60 space-y-2 border-t border-black/5 dark:border-white/10 pt-3">
                            <p>1. Pastikan Bluetooth perangkat kasir (laptop/tablet) dalam status aktif dan sudah di-pairing dengan printer.</p>
                            <p>2. Buka menu <strong>Pengaturan &rarr; Printer Kasir</strong> di Cooca, pilih nama printer yang sesuai dan lakukan uji coba *"Test Print"*.</p>
                            <p>3. Pastikan kertas thermal tidak terpasang terbalik dan penutup printer terkunci rapat.</p>
                        </div>
                    </div>

                    <!-- FAQ 2 -->
                    <div class="rounded-2xl bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/10 overflow-hidden shadow-2xs">
                        <button type="button" @click="expandedFaq = (expandedFaq === 2 ? null : 2)"
                            class="w-full p-4.5 text-left flex items-center justify-between gap-3 font-bold text-xs sm:text-sm text-black dark:text-white hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition cursor-pointer">
                            <span>Mengapa kas fisik laci kasir berbeda dengan perhitungan sistem saat tutup shift?</span>
                            <i data-lucide="chevron-down" class="w-4 h-4 transition-transform text-black/40 dark:text-white/40"
                                :class="expandedFaq === 2 ? 'rotate-180' : ''"></i>
                        </button>
                        <div x-show="expandedFaq === 2" x-collapse class="px-4.5 pb-4.5 text-xs text-black/60 dark:text-white/60 space-y-2 border-t border-black/5 dark:border-white/10 pt-3">
                            <p>Perbedaan (selisih lebih atau selisih kurang) biasanya disebabkan oleh salah kembalian manual, kas masuk/keluar non-penjualan yang lupa dicatat di tombol *"Uang Keluar Kas"*, atau transaksi non-tunai yang keliru diinput sebagai tunai.</p>
                            <p>Cooca akan tetap mencatat selisih tersebut ke dalam laporan audit pertanggungjawaban kasir sehingga pembukuan buku besar tetap akurat dan seimbang.</p>
                        </div>
                    </div>

                    <!-- FAQ 3 -->
                    <div class="rounded-2xl bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/10 overflow-hidden shadow-2xs">
                        <button type="button" @click="expandedFaq = (expandedFaq === 3 ? null : 3)"
                            class="w-full p-4.5 text-left flex items-center justify-between gap-3 font-bold text-xs sm:text-sm text-black dark:text-white hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition cursor-pointer">
                            <span>Apakah Cooca tetap bisa digunakan saat internet toko mati (Offline)?</span>
                            <i data-lucide="chevron-down" class="w-4 h-4 transition-transform text-black/40 dark:text-white/40"
                                :class="expandedFaq === 3 ? 'rotate-180' : ''"></i>
                        </button>
                        <div x-show="expandedFaq === 3" x-collapse class="px-4.5 pb-4.5 text-xs text-black/60 dark:text-white/60 space-y-2 border-t border-black/5 dark:border-white/10 pt-3">
                            <p>Ya. Terminal kasir Cooca dilengkapi arsitektur local storage caching. Kasir tetap bisa melayani transaksi offline dan mencetak struk belanja. Ketika koneksi internet pulih kembali, data transaksi akan otomatis tersinkronisasi ke server pusat Cooca.</p>
                        </div>
                    </div>

                    <!-- FAQ 4 -->
                    <div class="rounded-2xl bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/10 overflow-hidden shadow-2xs">
                        <button type="button" @click="expandedFaq = (expandedFaq === 4 ? null : 4)"
                            class="w-full p-4.5 text-left flex items-center justify-between gap-3 font-bold text-xs sm:text-sm text-black dark:text-white hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition cursor-pointer">
                            <span>Bagaimana cara mengundang akuntan atau konsultan luar untuk melihat pembukuan?</span>
                            <i data-lucide="chevron-down" class="w-4 h-4 transition-transform text-black/40 dark:text-white/40"
                                :class="expandedFaq === 4 ? 'rotate-180' : ''"></i>
                        </button>
                        <div x-show="expandedFaq === 4" x-collapse class="px-4.5 pb-4.5 text-xs text-black/60 dark:text-white/60 space-y-2 border-t border-black/5 dark:border-white/10 pt-3">
                            <p>Buka <strong>Pengaturan &rarr; Peran &amp; Hak Akses</strong>. Buat peran baru *"Akuntan Eksternal"* dengan hak akses hanya-baca (*Read-Only*) untuk menu Keuangan, Laporan, dan Jurnal. Dengan ini, akuntan dapat mengunduh neraca dan laba rugi tanpa bisa memodifikasi master data atau transaksi kasir.</p>
                        </div>
                    </div>
                </div>
            </section>

            <!-- ===================================================== -->
            <!-- FOOTER BANNER: CONTACT SUPPORT                        -->
            <!-- ===================================================== -->
            <div class="p-6 sm:p-8 rounded-2xl bg-gradient-to-br from-black/90 to-black/80 dark:from-white/10 dark:to-white/5 text-white flex flex-col sm:flex-row items-center justify-between gap-5 shadow-lg">
                <div class="space-y-1 text-center sm:text-left">
                    <h3 class="text-base sm:text-lg font-bold">{{ __('docs.masih_memiliki_pertanyaan_atau_mengalami_kendala') }}</h3>
                    <p class="text-xs text-white/70 max-w-lg">
                        Tim teknis dan konsultan bisnis Cooca siap membantu memastikan kelancaran operasional usaha Anda setiap hari.
                    </p>
                </div>
                <div class="flex items-center gap-3 shrink-0">
                    @if(\App\Support\Context::isOwner())
                        <a href="{{ route('feedback.bugs.create') }}"
                            class="px-5 py-2.5 rounded-xl bg-white text-black hover:bg-white/90 text-xs font-bold transition active:scale-95 shadow-sm">{{ __('docs.buka_tiket_kendala') }}</a>
                    @endif
                    <a href="https://wa.me/6281234567890?text=Halo%20Tim%20Cooca,%20saya%20butuh%20panduan%20penggunaan" target="_blank"
                        class="px-4 py-2.5 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-white text-xs font-bold transition flex items-center gap-1.5 shadow-sm">
                        <i data-lucide="message-circle" class="w-4 h-4"></i>
                        <span>WhatsApp Dukungan</span>
                    </a>
                </div>
            </div>

        </main>
    </div>

</div>
@endsection
