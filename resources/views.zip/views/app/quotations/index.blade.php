@extends('layouts.app', [
    'title' => __('sales.quotations.page_title'),
])

@section('content')
<div class="max-w-[1360px] mx-auto space-y-6 pb-28 sm:pb-32 lg:pb-10" x-data="{
    deleteModalOpen: false,
    deleteTarget: { url: '', name: '' },
    openDelete(url, name) {
        this.deleteTarget = { url, name };
        this.deleteModalOpen = true;
    },
    closeDelete() {
        this.deleteModalOpen = false;
        this.deleteTarget = { url: '', name: '' };
    },
    submitDelete() {
        if (this.deleteTarget.url) {
            const form = document.getElementById('form-delete-quotation');
            form.action = this.deleteTarget.url;
            form.submit();
        }
    }
}">
    <x-module-header
        module="sales"
        :title="__('sales.quotations.module_title')"
        :subtitle="__('sales.quotations.module_subtitle')">
        @if(\App\Support\Context::hasPermission('sales.pipeline'))
        <a href="{{ route('sales.quotations.create') }}" class="h-10 px-4 rounded-[12px] text-[13px] font-semibold text-white bg-[#007AFF] hover:bg-[#0071E3] active:scale-[0.97] transition-all flex items-center justify-center gap-2 shadow-sm shadow-[#007AFF]/25">
            <i data-lucide="plus" class="w-4 h-4"></i>
            <span>{{ __('sales.quotations.btn_create_new') }}</span>
        </a>
        @endif
    </x-module-header>

    <x-module-tabs module="sales" />

    <!-- ===================================================== -->
    <!-- 2. KPI SUMMARY ROW                                     -->
    <!-- ===================================================== -->
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
        <!-- Tile 1: Total Penawaran -->
        <div class="rounded-[14px] bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/5 p-4 flex flex-col justify-between">
            <span class="text-[12px] font-medium text-black/50 dark:text-white/50">{{ __('sales.quotations.kpi_total_issued') }}</span>
            <div class="mt-2 flex items-baseline justify-between">
                <span class="text-[22px] font-bold tabular-nums text-black dark:text-white">
                    {{ $quotations->total() }} {{ __('sales.quotations.kpi_docs_unit') }}
                </span>
                <span class="text-[11px] text-black/40 dark:text-white/40">{{ __('sales.quotations.kpi_pipeline') }}</span>
            </div>
        </div>

        <!-- Tile 2: Nilai Potensial Total -->
        <div class="rounded-[14px] bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/5 p-4 flex flex-col justify-between">
            <span class="text-[12px] font-medium text-black/50 dark:text-white/50">{{ __('sales.quotations.kpi_accumulated_value') }}</span>
            <div class="mt-2 flex items-baseline justify-between">
                <span class="text-[22px] font-bold tabular-nums text-[#007AFF] dark:text-[#0A84FF]">
                    Rp {{ number_format($quotations->sum('total_amount'), 0, ',', '.') }}
                </span>
                <span class="text-[11px] font-semibold text-[#007AFF] dark:text-[#0A84FF]">{{ __('sales.quotations.kpi_est_revenue') }}</span>
            </div>
        </div>

        <!-- Tile 3: Status Disetujui (System Green) -->
        <div class="rounded-[14px] bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/5 p-4 flex flex-col justify-between">
            <span class="text-[12px] font-medium text-black/50 dark:text-white/50">{{ __('sales.quotations.kpi_deal_accepted') }}</span>
            <div class="mt-2 flex items-baseline justify-between">
                <span class="text-[22px] font-bold tabular-nums text-[#34C759] dark:text-[#30D158]">
                    {{ $quotations->where('status', 'accepted')->count() }} {{ __('sales.quotations.kpi_accepted_unit') }}
                </span>
                <span class="text-[11px] font-semibold text-[#34C759] dark:text-[#30D158]">{{ __('sales.quotations.kpi_ready_convert') }}</span>
            </div>
        </div>
    </div>

    <!-- ===================================================== -->
    <!-- 3. CONTROLS: SEARCH & STATUS FILTER                    -->
    <!-- ===================================================== -->
    <div class="rounded-[14px] bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/5 p-3 sm:p-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <form method="GET" action="{{ route('sales.quotations.index') }}" class="w-full flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <!-- macOS Search Field -->
            <div class="relative flex-1">
                <svg class="w-4 h-4 text-black/35 dark:text-white/35 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
                </svg>
                <input type="text" name="search" value="{{ request('search') }}"
                       placeholder="{{ __('sales.quotations.search_placeholder') }}"
                       class="w-full h-9 bg-black/[0.04] dark:bg-white/[0.06] border-none rounded-[10px] pl-9 pr-3 text-[13px] text-black dark:text-white placeholder:text-black/35 dark:placeholder:text-white/35 focus:outline-none focus:ring-2 focus:ring-[#007AFF]/50 transition">
            </div>

            <!-- Status Filter -->
            <div class="flex items-center gap-2">
                <select name="status" onchange="this.form.submit()" class="h-9 bg-black/[0.04] dark:bg-white/[0.06] border-none rounded-[10px] px-3 text-[13px] text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-[#007AFF]/50 transition">
                    <option value="">{{ __('sales.quotations.filter_all_status') }}</option>
                    <option value="sent" {{ request('status') === 'sent' ? 'selected' : '' }}>{{ __('sales.quotations.status_sent') }}</option>
                    <option value="accepted" {{ request('status') === 'accepted' ? 'selected' : '' }}>{{ __('sales.quotations.status_accepted') }}</option>
                    <option value="rejected" {{ request('status') === 'rejected' ? 'selected' : '' }}>{{ __('sales.quotations.status_rejected') }}</option>
                    <option value="expired" {{ request('status') === 'expired' ? 'selected' : '' }}>{{ __('sales.quotations.status_expired') }}</option>
                </select>

                @if(request('search') || request('status'))
                <a href="{{ route('sales.quotations.index') }}" class="h-9 px-3 rounded-[10px] text-[12px] font-medium text-black/60 dark:text-white/60 hover:text-black dark:hover:text-white bg-black/[0.04] dark:bg-white/[0.06] hover:bg-black/[0.08] transition-colors inline-flex items-center gap-1">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                    <span>{{ __('sales.quotations.btn_reset') }}</span>
                </a>
                @endif
            </div>
        </form>
    </div>

    <!-- ===================================================== -->
    <!-- 4. DENSE DATA TABLE (DESKTOP & TABLET)                 -->
    <!-- ===================================================== -->
    <div class="hidden sm:block rounded-[14px] bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/5 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-[13px]">
                <thead>
                    <tr class="border-b border-black/5 dark:border-white/10">
                        <th class="px-4 py-2.5 text-[11px] font-semibold uppercase tracking-wide text-black/40 dark:text-white/40">{{ __('sales.quotations.col_quotation_number') }}</th>
                        <th class="px-4 py-2.5 text-[11px] font-semibold uppercase tracking-wide text-black/40 dark:text-white/40">{{ __('sales.quotations.col_customer') }}</th>
                        <th class="px-4 py-2.5 text-[11px] font-semibold uppercase tracking-wide text-black/40 dark:text-white/40">{{ __('sales.quotations.col_date') }}</th>
                        <th class="px-4 py-2.5 text-[11px] font-semibold uppercase tracking-wide text-black/40 dark:text-white/40">{{ __('sales.quotations.col_expiry_date') }}</th>
                        <th class="px-4 py-2.5 text-[11px] font-semibold uppercase tracking-wide text-black/40 dark:text-white/40 text-right">{{ __('sales.quotations.col_total_amount') }}</th>
                        <th class="px-4 py-2.5 text-[11px] font-semibold uppercase tracking-wide text-black/40 dark:text-white/40 text-center">{{ __('sales.quotations.col_status') }}</th>
                        <th class="px-4 py-2.5 text-[11px] font-semibold uppercase tracking-wide text-black/40 dark:text-white/40 text-right whitespace-nowrap sticky right-0 bg-[#F9F9FA] dark:bg-[#1E1E20] z-10 border-l border-black/[0.04] dark:border-white/[0.06] shadow-[-6px_0_12px_-4px_rgba(0,0,0,0.05)]">{{ __('sales.quotations.col_actions') }}</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-black/[0.04] dark:divide-white/[0.06]">
                    @forelse($quotations as $q)
                    <tr class="hover:bg-black/[0.02] dark:hover:bg-white/[0.03] transition-colors group">
                        <td class="px-4 py-3">
                            <a href="{{ route('sales.quotations.show', $q) }}" class="font-medium text-[#007AFF] hover:underline">
                                {{ $q->quotation_number }}
                            </a>
                        </td>
                        <td class="px-4 py-3 font-medium text-black dark:text-white">
                            {{ $q->customer->name }}
                        </td>
                        <td class="px-4 py-3 text-black/60 dark:text-white/60 tabular-nums">
                            {{ $q->date->format('d M Y') }}
                        </td>
                        <td class="px-4 py-3 text-black/60 dark:text-white/60 tabular-nums">
                            {{ $q->expiry_date ? $q->expiry_date->format('d M Y') : '-' }}
                        </td>
                        <td class="px-4 py-3 text-right tabular-nums font-semibold text-black dark:text-white">
                            Rp {{ number_format($q->total_amount, 0, ',', '.') }}
                        </td>
                        <td class="px-4 py-3 text-center">
                            @if($q->status === 'accepted')
                                <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[#34C759]/12 text-[#248A3D] dark:text-[#30D158]">
                                    <span class="w-1.5 h-1.5 rounded-full bg-[#34C759]"></span> {{ __('sales.quotations.status_accepted') }}
                                </span>
                            @elseif($q->status === 'sent')
                                <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[#007AFF]/12 text-[#007AFF] dark:text-[#0A84FF]">
                                    <span class="w-1.5 h-1.5 rounded-full bg-[#007AFF]"></span> {{ __('sales.quotations.status_sent') }}
                                </span>
                            @elseif($q->status === 'rejected')
                                <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[#FF3B30]/12 text-[#C41E17] dark:text-[#FF453A]">
                                    <span class="w-1.5 h-1.5 rounded-full bg-[#FF3B30]"></span> {{ __('sales.quotations.status_rejected') }}
                                </span>
                            @else
                                <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-black/[0.06] dark:bg-white/[0.08] text-black/60 dark:text-white/60">
                                    {{ strtoupper($q->status) }}
                                </span>
                            @endif
                        </td>
                        <td class="px-4 py-3 text-right whitespace-nowrap sticky right-0 bg-white dark:bg-[#1C1C1E] group-hover:bg-[#F9F9FB] dark:group-hover:bg-[#252528] z-10 border-l border-black/[0.04] dark:border-white/[0.06] shadow-[-6px_0_12px_-4px_rgba(0,0,0,0.05)]">
                            <div class="flex items-center justify-end gap-2">
                                <a href="{{ route('sales.quotations.show', $q) }}"
                                    class="inline-flex items-center min-h-[44px] sm:min-h-0 h-9 px-3 rounded-[10px] bg-[#007AFF]/10 hover:bg-[#007AFF]/20 text-xs font-semibold text-[#007AFF] transition-colors"
                                    title="{{ __('sales.quotations.btn_detail') }}">
                                    <i data-lucide="eye" class="w-3.5 h-3.5 mr-1.5 shrink-0"></i>
                                    <span>{{ __('sales.quotations.btn_detail') }}</span>
                                </a>

                                <div x-data="{ open: false }" class="relative inline-block text-left">
                                    <button type="button" 
                                            @click="open = !open" 
                                            @click.outside="open = false"
                                            aria-label="{{ __('common.more_actions') }}"
                                            class="min-h-[44px] min-w-[44px] sm:min-h-0 sm:min-w-0 w-9 h-9 rounded-[10px] flex items-center justify-center text-black/60 dark:text-white/60 hover:text-black dark:hover:text-white hover:bg-black/5 dark:hover:bg-white/10 transition-colors cursor-pointer">
                                        <i data-lucide="more-horizontal" class="w-4 h-4"></i>
                                    </button>

                                    <div x-show="open"
                                         x-cloak
                                         x-transition:enter="transition ease-out duration-100"
                                         x-transition:enter-start="transform opacity-0 scale-95"
                                         x-transition:enter-end="transform opacity-100 scale-100"
                                         x-transition:leave="transition ease-in duration-75"
                                         x-transition:leave-start="transform opacity-100 scale-100"
                                         x-transition:leave-end="transform opacity-0 scale-95"
                                         class="absolute right-0 mt-1.5 w-48 rounded-[14px] bg-white dark:bg-[#2C2C2E] border border-black/10 dark:border-white/10 shadow-2xl py-1.5 z-30 text-left">
                                        <a href="{{ route('sales.quotations.pdf', $q) }}" target="_blank"
                                           class="flex items-center gap-2.5 px-3.5 py-2 text-xs font-medium text-gray-700 dark:text-gray-200 hover:bg-black/5 dark:hover:bg-white/10 transition-colors">
                                            <i data-lucide="printer" class="w-4 h-4 text-gray-400"></i>
                                            <span>{{ __('common.download_pdf') }}</span>
                                        </a>
                                        @if (\App\Support\Context::hasPermission('sales.pipeline') || \App\Support\Context::hasPermission('sales.view'))
                                        <a href="{{ route('sales.quotations.edit', $q) }}"
                                           class="flex items-center gap-2.5 px-3.5 py-2 text-xs font-medium text-gray-700 dark:text-gray-200 hover:bg-black/5 dark:hover:bg-white/10 transition-colors">
                                            <i data-lucide="pencil" class="w-4 h-4 text-gray-400"></i>
                                            <span>{{ __('sales.edit_penawaran_2') }}</span>
                                        </a>
                                        @endif
                                        @if($q->status === 'draft' && \App\Support\Context::hasPermission('sales.pipeline'))
                                        <div class="h-px bg-black/5 dark:bg-white/10 my-1"></div>
                                        <button type="button" @click="open = false; openDelete('{{ route('sales.quotations.destroy', $q) }}', '{{ addslashes($q->quotation_number) }}')"
                                            class="w-full flex items-center gap-2.5 px-3.5 py-2 text-xs font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors text-left cursor-pointer">
                                            <i data-lucide="trash-2" class="w-4 h-4 text-red-500"></i>
                                            <span>{{ __('admin.hapus_penawaran') }}</span>
                                        </button>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="px-4 py-12 text-center text-[13px] text-black/40 dark:text-white/40">
                            <div class="flex flex-col items-center justify-center gap-2">
                                <svg class="w-8 h-8 text-black/20 dark:text-white/20" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                                </svg>
                                <span>{{ __('sales.quotations.empty_title') }}</span>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <!-- ===================================================== -->
    <!-- 5. MOBILE GROUPED INSET LIST (iOS 18 Style)            -->
    <!-- ===================================================== -->
    <div class="sm:hidden rounded-[14px] bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/5 overflow-hidden divide-y divide-black/[0.04] dark:divide-white/[0.06]">
        @forelse($quotations as $q)
        <div class="p-3.5 flex items-center justify-between gap-3 active:bg-black/[0.03] dark:active:bg-white/[0.05] transition-colors">
            <a href="{{ route('sales.quotations.show', $q) }}" class="min-w-0 flex-1">
                <div class="flex items-center gap-2">
                    <p class="text-[15px] font-medium text-black dark:text-white truncate">{{ $q->quotation_number }}</p>
                    @if($q->status === 'accepted')
                        <span class="w-1.5 h-1.5 rounded-full bg-[#34C759] shrink-0"></span>
                    @elseif($q->status === 'sent')
                        <span class="w-1.5 h-1.5 rounded-full bg-[#007AFF] shrink-0"></span>
                    @elseif($q->status === 'rejected')
                        <span class="w-1.5 h-1.5 rounded-full bg-[#FF3B30] shrink-0"></span>
                    @else
                        <span class="w-1.5 h-1.5 rounded-full bg-black/30 dark:bg-white/30 shrink-0"></span>
                    @endif
                </div>
                <p class="text-[13px] text-black/60 dark:text-white/60 truncate mt-0.5">{{ $q->customer->name }}</p>
                <div class="flex items-center gap-2 mt-1 text-[12px] text-black/45 dark:text-white/45 tabular-nums">
                    <span>{{ $q->date->format('d M Y') }}</span>
                    <span>&bull;</span>
                    <span class="font-semibold text-black dark:text-white">Rp {{ number_format($q->total_amount, 0, ',', '.') }}</span>
                </div>
            </a>
            <div class="flex items-center gap-1.5 shrink-0">
                <a href="{{ route('sales.quotations.pdf', $q) }}" target="_blank"
                   class="h-8 px-2 rounded-[8px] text-[12px] font-medium text-black/70 dark:text-white/70 bg-black/[0.04] dark:bg-white/[0.06] flex items-center gap-1"
                   title="{{ __('common.download_pdf') }}">
                    <i data-lucide="printer" class="w-3.5 h-3.5 text-black/50 dark:text-white/50"></i>
                    <span>PDF</span>
                </a>
                @if(\App\Support\Context::hasPermission('sales.pipeline') || \App\Support\Context::hasPermission('sales.view'))
                    <a href="{{ route('sales.quotations.edit', $q) }}"
                       class="h-8 px-2 rounded-[8px] text-[12px] font-medium text-black/70 dark:text-white/70 bg-black/[0.04] dark:bg-white/[0.06] flex items-center gap-1"
                       title="{{ __('common.edit') }}">
                        <i data-lucide="edit-3" class="w-3.5 h-3.5 text-black/50 dark:text-white/50"></i>
                        <span>{{ __('common.edit') }}</span>
                    </a>
                @endif
                <a href="{{ route('sales.quotations.show', $q) }}" class="h-8 px-2.5 rounded-[8px] text-[12px] font-medium text-[#007AFF] bg-[#007AFF]/10 flex items-center gap-0.5">
                    <span>{{ __('common.detail') }}</span>
                    <i data-lucide="chevron-right" class="w-3.5 h-3.5"></i>
                </a>
                @if($q->status === 'draft' && \App\Support\Context::hasPermission('sales.pipeline'))
                    <button type="button" @click="openDelete('{{ route('sales.quotations.destroy', $q) }}', '{{ addslashes($q->quotation_number) }}')"
                            class="h-8 w-8 rounded-[8px] text-[#FF3B30] bg-[#FF3B30]/10 flex items-center justify-center"
                            title="{{ __('admin.hapus_penawaran') }}">
                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                    </button>
                @endif
            </div>
        </div>
        @empty
        <div class="p-8 text-center text-[13px] text-black/40 dark:text-white/40">
            {{ __('sales.quotations.empty_title') }}
        </div>
        @endforelse
    </div>

    <!-- ===================================================== -->
    <!-- 6. PAGINATION                                         -->
    <!-- ===================================================== -->
    @if($quotations->total() > 0)
    <div class="rounded-[14px] bg-white dark:bg-[#1C1C1E] border border-black/5 dark:border-white/5 p-3">
        {{ $quotations->links() }}
    </div>
    @endif

    <!-- ===================================================== -->
    <!-- 7. APPLE ALERT DIALOG (Delete Confirmation Modal)     -->
    <!-- ===================================================== -->
    <template x-teleport="body">
        <div x-show="deleteModalOpen"
             x-cloak
             class="fixed inset-0 z-[220] overflow-y-auto"
             @keydown.escape.window="closeDelete()"
             role="alertdialog"
             aria-modal="true"
             aria-labelledby="quotation-delete-dialog-title">

            <div x-show="deleteModalOpen"
                x-transition:enter="ease-out duration-200"
                x-transition:enter-start="opacity-0"
                x-transition:enter-end="opacity-100"
                x-transition:leave="ease-in duration-150"
                x-transition:leave-start="opacity-100"
                x-transition:leave-end="opacity-0"
                class="fixed inset-0 bg-black/40 backdrop-blur-sm transition-opacity"
                @click="closeDelete()"></div>

            <div class="flex min-h-full items-center justify-center p-4 text-center">
                <div x-show="deleteModalOpen"
                     x-transition:enter="transition ease-out duration-200"
                     x-transition:enter-start="opacity-0 scale-95"
                     x-transition:enter-end="opacity-100 scale-100"
                     x-transition:leave="transition ease-in duration-150"
                     x-transition:leave-start="opacity-100 scale-100"
                     x-transition:leave-end="opacity-0 scale-95"
                     class="w-full max-w-[320px] rounded-[18px] bg-white/90 dark:bg-[#2C2C2E]/90 backdrop-blur-2xl border border-black/10 dark:border-white/10 shadow-2xl overflow-hidden transition-all text-center">

                    <div class="px-4 pt-5 pb-4">
                        <p id="quotation-delete-dialog-title" class="text-[17px] font-semibold text-black dark:text-white">{{ __('sales.confirm_delete_quotation_title') }}?</p>
                        <p class="text-[13px] text-black/60 dark:text-white/60 mt-1 leading-snug">
                            {{ __('sales.confirm_delete_quotation_msg') }} <span class="font-medium text-black dark:text-white" x-text="deleteTarget.name"></span>? {{ __('sales.action_cannot_be_undone') }}
                        </p>
                    </div>

                    <div class="grid grid-cols-2 border-t border-black/10 dark:border-white/10 text-[15px] font-medium">
                        <button type="button" @click="closeDelete()"
                                class="min-h-[44px] py-3 text-[#007AFF] border-r border-black/10 dark:border-white/10 active:bg-black/5 dark:active:bg-white/5 transition-colors cursor-pointer">{{ __('common.cancel') }}</button>
                        <button type="button" @click="submitDelete()"
                                class="min-h-[44px] py-3 text-[#FF3B30] font-semibold active:bg-black/5 dark:active:bg-white/5 transition-colors cursor-pointer">{{ __('common.delete') }}</button>
                    </div>
                </div>
            </div>
        </div>
    </template>

    <!-- Hidden Quotation Delete Form -->
    <form id="form-delete-quotation" method="POST" action="" class="hidden">
        @csrf
        @method('DELETE')
    </form>
</div>
@endsection
